export const environment = {
  production: true,
  apiUrl: 'https://mobilemoneyapi.herokuapp.com/'
  //apiUrl: 'http://localhost:5001/'
};
