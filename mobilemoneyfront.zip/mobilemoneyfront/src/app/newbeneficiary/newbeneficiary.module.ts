import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewbeneficiaryPageRoutingModule } from './newbeneficiary-routing.module';

import { NewbeneficiaryPage } from './newbeneficiary.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewbeneficiaryPageRoutingModule
  ],
  declarations: [NewbeneficiaryPage]
})
export class NewbeneficiaryPageModule {}
