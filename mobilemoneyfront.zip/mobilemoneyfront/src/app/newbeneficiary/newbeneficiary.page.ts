import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController } from '@ionic/angular';

import { AuthConstants } from '../config/auth-constants';
import { AuthService } from '../services/auth.service';
import { StorageService } from '../services/storage.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Component({
  selector: 'app-newbeneficiary',
  templateUrl: './newbeneficiary.page.html',
  styleUrls: ['./newbeneficiary.page.scss'],
})
export class NewbeneficiaryPage implements OnInit {
  beneficiaryData = {
    accountName: "",
    accountNumber: "",
    sortCode: "",
    beneficiaryName: "",
    phoneNumber: "",
    pinCode: ""
  }
  showBeneficiaryProceed = false;
  hideBeneficiaryRegister = true;
  userData : any;
  beneficiaryEntry = {
    isChecked: ""
  }
  
  constructor(public router: Router, public alertController: AlertController,
    private authService: AuthService,
    private storageService: StorageService,
    private toastService: ToastService,
    private ionLoader: LoaderService) { 
      this.getUserDetails();
    }

  ngOnInit() {}

  async getUserDetails() {
    const returnedData = await this.storageService.get(AuthConstants.AUTH)
    this.userData = returnedData?.info;
    // console.log("loggedin details:::", this.userData);
    this.beneficiaryData.phoneNumber = this.userData.phone;
    return this.userData;
  }

  async presentAlert(msg) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Beneficiary',
      message: msg,
      buttons: ['OK']
    });
    await alert.present();
    await alert.onDidDismiss();
  }

  validateBeneficiaryInputs() {
    let accountNumber = String(this.beneficiaryData.accountNumber);
    let accountName = this.beneficiaryData.accountName;
    let beneficiaryName = this.beneficiaryData.beneficiaryName;
    let phoneNumber = this.beneficiaryData.phoneNumber;
    let sortCode = this.beneficiaryData.sortCode;
    let pinCode = String(this.beneficiaryData.pinCode);
    
    const retStatus = (accountNumber.length > 0 &&  
      accountName.length > 0 && 
      beneficiaryName.length > 0 &&
      sortCode.length > 0 &&
      phoneNumber.length > 0 && pinCode.length > 0);
    console.log("account num:::", retStatus)
    return retStatus;
  }

  registerData() {
    this.showBeneficiaryProceed = true;
    this.hideBeneficiaryRegister = false;
    // console.log("data:::", this.beneficiaryData);
  }

  confirmData() {
    console.log("data:::", this.beneficiaryData);
    console.log("validateBeneficiaryInputs:::", this.validateBeneficiaryInputs());
    if(this.validateBeneficiaryInputs()) {
      this.showLoader();
      this.authService.createBeneficiary(this.beneficiaryData).subscribe((res: any) => {
          console.log("beneficiary result :", res)
          this.hideLoader();
          if (res.success) {
            // this.storageService.store(AuthConstants.AUTH, res.data);
            // this.router.navigate(['/tabs']);
            this.presentAlert('Beneficiary added successfully.');
            this.toastService.presentToast('Beneficiary added successfully.');
          } else {
            this.presentAlert(res.message);
            this.toastService.presentToast(res.message);
          }
        },
        (error: any) => {
          // console.log("login error :", error)
          this.hideLoader();
          this.presentAlert(error?.error?.message);
          this.toastService.presentToast(error?.error?.message);
        }
      );
    } else {
      this.toastService.presentToast('Please enter Account Number and Account Name');
    }
  }

  showLoader() {
    this.ionLoader.showLoader();
    setTimeout(() => {
      this.hideLoader();
    }, 3000);
  }

  hideLoader() {
    this.ionLoader.hideLoader();
  }

}
