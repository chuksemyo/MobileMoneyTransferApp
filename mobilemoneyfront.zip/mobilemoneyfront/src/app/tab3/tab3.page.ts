import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController } from '@ionic/angular';

import { AuthConstants } from '../config/auth-constants';
import { AuthService } from '../services/auth.service';
import { StorageService } from '../services/storage.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  transferData = {
    amount: "",
    accountNo: "",
    remark: ""
  }
  constructor() {}

}
