import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpin',
  templateUrl: './forgotpin.page.html',
  styleUrls: ['./forgotpin.page.scss'],
})
export class ForgotpinPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
