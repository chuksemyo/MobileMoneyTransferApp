import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddprofilepicturePageRoutingModule } from './addprofilepicture-routing.module';

import { AddprofilepicturePage } from './addprofilepicture.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddprofilepicturePageRoutingModule
  ],
  declarations: [AddprofilepicturePage]
})
export class AddprofilepicturePageModule {}
