import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardsadd',
  templateUrl: './cardsadd.page.html',
  styleUrls: ['./cardsadd.page.scss'],
})
export class CardsaddPage implements OnInit {
  cardData = {
    cardname: "",
    cardno: "",
    expiry: "",
    cvv: ""
  }
  constructor() { }

  ngOnInit() {
  }

  registerCard() {
    
  }  

}
