import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CardsaddPageRoutingModule } from './cardsadd-routing.module';

import { CardsaddPage } from './cardsadd.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CardsaddPageRoutingModule
  ],
  declarations: [CardsaddPage]
})
export class CardsaddPageModule {}
