export class AuthConstants {
    public static readonly AUTH = 'userData'
    public static readonly AUTHPHONE = 'userPhone'
    public static readonly WALLETBALANCE = 'userWalletBalance'
};