import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthConstants } from './../config/auth-constants';
import { AuthService } from './../services/auth.service';
import { StorageService } from './../services/storage.service';
import { ToastService } from './../services/toast.service';

@Component({
  selector: 'app-setpin',
  templateUrl: './setpin.page.html',
  styleUrls: ['./setpin.page.scss'],
})
export class SetpinPage implements OnInit {
  pData = {
    pincode: '',
    cpincode: '',
  }
  phoneNumber: any;
  emailAddress: any;
  userDetails: any;
  constructor(private authService: AuthService,
    private toastService: ToastService,
    private storageService: StorageService,
    private router: Router) { 
      if (this.router.getCurrentNavigation().extras.state) {
        const routeState = this.router.getCurrentNavigation().extras.state;
        if (routeState) {
          // this.userDetails = routeState.details ? JSON.parse(routeState.details) : '';
          this.phoneNumber = routeState.phone ? routeState.phone : '';
          this.emailAddress = routeState.email ? routeState.email : '';
        }
      }
    }

  ngOnInit() {
  }

  validateInputs() {
    // console.log(this.pData);
    let pincode = this.pData.pincode.trim();
    let cpincode = this.pData.cpincode.trim();
    return (
      this.pData.pincode &&
      this.pData.cpincode &&
      pincode.length > 0 &&
      cpincode.length > 0
    );
  }

  nextAction() {
    console.log(this.pData)
    if (this.validateInputs()) {
      if(this.pData.pincode != this.pData.cpincode) {
        this.toastService.presentToast(
          'Kindly confirm pin code values are the same.'
        );
      } else {
        const otpDetails = {
          phone: this.phoneNumber,
          newPassword: this.pData.pincode
        } 
        this.authService.setPassword(otpDetails).subscribe((res: any) => {
            console.log("setpin res:::", res)
            if (res.success) {
              this.storageService.store(AuthConstants.AUTH, res.data).then(res => {
                  this.router.navigate(['/addprofilepicture'], {
                    state: {
                      details: this.userDetails,
                      phone: this.phoneNumber,
                      email: this.emailAddress
                    }
                  });
              });
            } else {
              this.toastService.presentToast(
                'Pin already exists, please enter new details.'
              );
            }
          },
          (error: any) => { 
            console.log("setpin error:::", error)
            this.toastService.presentToast('Network Issue.');
          });
        // this.router.navigateByUrl('addprofilepicture');
      }
    } else {
      this.toastService.presentToast(
        'Please complete otp values.'
      );
    }
  }

}
