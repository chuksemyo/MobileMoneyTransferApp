import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController } from '@ionic/angular';

import { AuthConstants } from '../config/auth-constants';
import { AuthService } from '../services/auth.service';
import { StorageService } from '../services/storage.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  userData : any
  loggedInUser: {}
  walletDetails: any;
  walletBalance: number;
  balanceData = 0;
  constructor(public router: Router, public alertController: AlertController,
    private authService: AuthService,
    private storageService: StorageService,
    private toastService: ToastService,
    private ionLoader: LoaderService) {
      this.getUserDetails();
    }

    async getUserDetails() {
      const returnedData = await this.storageService.get(AuthConstants.AUTH)
      this.userData = returnedData?.info;
      this.getUserWallet(this.userData.phone);
      console.log("loggedin details:::", this.userData);
      return this.userData;
    }

    async getBalance() {
      const returnedData = await this.storageService.get(AuthConstants.WALLETBALANCE)
      this.balanceData = (returnedData == null || returnedData == undefined || returnedData == "" ) ? 0 : returnedData;
      this.walletBalance = this.balanceData;
      console.log("balanceData details:::", this.balanceData);
      return this.balanceData;
    }

    async getUserWallet(phone) {
      console.log("loggedin phone:::", phone);
      this.authService.getApiUrl("/balance/"+phone).subscribe((res: any) => {
          console.log("get wallet balance:::", res)
          // this.hideLoader();
          if (res.success) {
            this.walletDetails = res.data;
            this.walletBalance = this.walletDetails?.amount;
          } else {
            console.log("wallet else :", res)
            this.walletBalance = 0;
          }
        },
        (error: any) => {
          console.log("wallet error :", error)
          // this.hideLoader();
          // this.presentAlert(error?.error?.message);
          // this.toastService.presentToast(error?.error?.message);
        }
      );
    }

    doRefresh(refresher) {
      console.log('Begin async operation', refresher);
      this.getUserWallet(this.userData?.phone);
      setTimeout(() => {
        console.log('Async operation has ended');
        refresher.target.complete();
      }, 3000);
    }

}
