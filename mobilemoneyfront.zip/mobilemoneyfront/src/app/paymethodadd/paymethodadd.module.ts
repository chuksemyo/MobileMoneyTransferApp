import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PaymethodaddPageRoutingModule } from './paymethodadd-routing.module';

import { PaymethodaddPage } from './paymethodadd.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PaymethodaddPageRoutingModule
  ],
  declarations: [PaymethodaddPage]
})
export class PaymethodaddPageModule {}
