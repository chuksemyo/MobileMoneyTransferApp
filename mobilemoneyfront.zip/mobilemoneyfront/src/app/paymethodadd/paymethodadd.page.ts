import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymethodadd',
  templateUrl: './paymethodadd.page.html',
  styleUrls: ['./paymethodadd.page.scss'],
})
export class PaymethodaddPage implements OnInit {
  cardData = {
    cardname: "",
    cardno: "",
    expiry: "",
    cvv: ""
  }
  constructor() { }

  ngOnInit() {
  }

  registerCard() {
    
  }

}
