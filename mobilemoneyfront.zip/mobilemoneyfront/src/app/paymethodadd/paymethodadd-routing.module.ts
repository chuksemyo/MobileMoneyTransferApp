import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymethodaddPage } from './paymethodadd.page';

const routes: Routes = [
  {
    path: '',
    component: PaymethodaddPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymethodaddPageRoutingModule {}
