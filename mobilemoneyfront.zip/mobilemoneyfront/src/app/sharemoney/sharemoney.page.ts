import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sharemoney',
  templateUrl: './sharemoney.page.html',
  styleUrls: ['./sharemoney.page.scss'],
})
export class SharemoneyPage implements OnInit {
  transferData = {
    amount: "",
    accountNo: "",
    remark: ""
  }
  constructor() { }

  ngOnInit() {
  }

}
