import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController } from '@ionic/angular';

import { AuthConstants } from '../config/auth-constants';
import { AuthService } from '../services/auth.service';
import { StorageService } from '../services/storage.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  transferData = {
    amount: "",
    accountNumber: "",
    accountName: "",
    remarks: "",
    beneficiary: "",
    phoneNumber: "",
    transferType: "",
    receiverPhone: "",
    pinCode: ""
  }
  // transferViaBank = {
  //   amount: "",
  //   accountNumber: "",
  //   accountName: "",
  //   remarks: "",
  //   beneficiary: "",
  //   transferType: ""
  // }
  // transferViaPhone = {
  //   amount: "",
  //   remarks: "",
  //   phoneNumber: "",
  //   transferType: "",
  //   receiverPhone: ""
  // }
  transferViaChannel= {}
  transferAmount: any;
  userData : any;
  beneficiaryList : any;
  userPhoneNumber: any;
  beneficiaryUser: any;
  transferIcon  = "checkmark-circle"
  transferIcon2  = "ellipse-outline"
  userTransferType: any;
  bankAccountTransferType: any;
  showProceed = false;
  hideRegister = true;
  constructor(public router: Router, public alertController: AlertController,
    private authService: AuthService,
    private storageService: StorageService,
    private toastService: ToastService,
    private ionLoader: LoaderService) { 
      this.transferData.transferType = "user";
      this.getUserDetails();
    }
  
  async getUserDetails() {
    const returnedData = await this.storageService.get(AuthConstants.AUTH)
    this.userData = returnedData?.info;
    this.userPhoneNumber = this.userData.phone;
    this.transferData.phoneNumber = this.userData.phone;
    // console.log("loggedin details:::", this.userData);
    this.getUserBeneficiary(this.userPhoneNumber);
    return this.userData;
  }

  async getUserBeneficiary(phone) {
    console.log("loggedin phone:::", phone);
    this.authService.getUserBeneficiary(phone).subscribe((res: any) => {
        console.log("get beneficiary result :", res)
        this.hideLoader();
        if (res.success) {
          this.beneficiaryList = res.data;
          // this.storageService.store(AuthConstants.AUTH, res.data);
          // this.router.navigate(['/tabs']);
          // this.presentAlert('Beneficiary added successfully.');
          // this.toastService.presentToast('Beneficiary added successfully.');
        } else {
          // this.presentAlert(res.message);
          // this.toastService.presentToast(res.message);
          console.log("beneficiary else :", res)
        }
      },
      (error: any) => {
        console.log("beneficiary error :", error)
        // this.hideLoader();
        // this.presentAlert(error?.error?.message);
        // this.toastService.presentToast(error?.error?.message);
      }
    );
  }

  onChangeBeneficiary(beneficiary) {
    // console.log("Beneficiary User:::", this.beneficiaryUser);   
    // console.log(beneficiary);
    this.transferData.accountName = this.beneficiaryUser.accountName;
    this.transferData.accountNumber = this.beneficiaryUser.accountNumber;
    this.transferData.beneficiary = this.beneficiaryUser._id;
  }

  defaultAmount(staticAmount) {
    this.transferData.amount = this.transferAmount = staticAmount;
  }

  getTransferType(type) {
    if(type=='user') {
      this.transferData.transferType = 'user';
      this.transferIcon = "checkmark-circle";
      this.transferIcon2 = "ellipse-outline";
    } else {
      this.transferData.transferType = 'bankaccount';
      this.transferIcon2 = "checkmark-circle";
      this.transferIcon = "ellipse-outline";
    }
  }

    
  validateTransferInputs() {
    let amount = String(this.transferData.amount);
    let phoneNumber = this.transferData.phoneNumber;
    let accountNumber = String(this.transferData.accountNumber);
    let receiverPhone = String(this.transferData.receiverPhone);
    if(this.transferData.transferType == 'user') {
      const retStatus = (amount.length > 0 && receiverPhone.length > 0);
      console.log("transfer inputs user:::", retStatus)
      return retStatus;
    } else {
      const retStatus = (amount.length > 0 && phoneNumber.length > 0 && accountNumber.length > 0);
      console.log("transfer inputs bank:::", retStatus)
      return retStatus;
    }
  }


  transferMoney() {
    console.log(this.transferData);
    this.showProceed = true;
    this.hideRegister = false;
  }

  confirmData() {
    console.log("data:::", this.transferData);
    if(this.validateTransferInputs()) {
      this.showLoader();
      this.transferData.amount = String(this.transferData.amount);
      if(this.transferData.transferType == 'user') {
        this.transferViaChannel = {
          amount: this.transferData.amount,
          remarks: this.transferData.remarks,
          phoneNumber: this.transferData.phoneNumber,
          transferType: this.transferData.transferType,
          receiverPhone: this.transferData.receiverPhone,
          pinCode: this.transferData.pinCode
        }
      } else {
        this.transferViaChannel = {
          amount: this.transferData.amount,
          accountNumber: this.transferData.accountNumber,
          accountName: this.transferData.accountName,
          remarks: this.transferData.remarks,
          beneficiary: this.transferData.beneficiary,
          transferType: this.transferData.transferType,
          pinCode: this.transferData.pinCode
        }
      }  
      this.authService.postApiUrl("/create-transfer", this.transferViaChannel).subscribe((res: any) => {
          console.log("transfer result :", res)
          this.hideLoader();
          if (res.success) {
            this.storageService.store(AuthConstants.WALLETBALANCE, res.data?.info?.wallet);
            this.presentAlert(res.message);
            this.toastService.presentToast('Transfer successfully made.');
            setTimeout(() => {
              this.showProceed = false;
              this.hideRegister = true;
              this.router.navigate(['/tabs']);
            }, 2000);
          } else {
            this.showProceed = false;
            this.hideRegister = true;
            this.presentAlert(res.message);
            this.toastService.presentToast(res.message);
          }
        },
        (error: any) => {
          this.hideLoader();
          this.showProceed = false;
          this.hideRegister = true;
          this.presentAlert(error?.error?.message);
          this.toastService.presentToast(error?.error?.message);
        }
      );
    } else {
      this.toastService.presentToast('Please fill corresponding fields');
    }
  }


  async presentAlert(msg) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Transfer Money',
      message: msg,
      buttons: ['OK']
    });
    await alert.present();
    await alert.onDidDismiss();
  }

  showLoader() {
    this.ionLoader.showLoader();
    setTimeout(() => {
      this.hideLoader();
    }, 3000);
  }

  hideLoader() {
    this.ionLoader.hideLoader();
  }


}
