import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { AlertController } from '@ionic/angular';

import { AuthConstants } from '../config/auth-constants';
import { AuthService } from '../services/auth.service';
import { StorageService } from '../services/storage.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Component({
  selector: 'app-addmoney',
  templateUrl: 'addmoney.page.html',
  styleUrls: ['addmoney.page.scss']
})
export class AddmoneyPage {
  addMoneyData = {
    amount: "",
    payMethod: [],
    payType: "",
    remarks: "",
    phoneNumber: "",
    pinCode: ""
  }
  payMethodData = [
    {
      bankName: "Barclays Bank",
      accountNumber: "5555580100",
      accountName: "Black Marvin",
      sortCode: "5689",
      payType: "bank"
    },
    {
      bankName: "Monzo",
      accountNumber: "4325550129",
      accountName: "Chuks Emyo",
      sortCode: "4004",
      payType: "bank"
    },
    {
      bankName: "NatWest Bank",
      accountNumber: "9055234918",
      accountName: "Emeka Igwe",
      sortCode: "1990",
      payType: "bank"
    },
    {
      bankName: "Mastercard",
      accountNumber: "4590552349183456",
      accountName: "Emeka Igwe",
      expiryDate: "11/26",
      cvv: "1990",
      payType: "card"
    }
  ]
  payMethodCardData = {
    cardType: "",
    cardName: "",
    cardNumber: "",
    expiryYear: "",
    expiryMonth: "",
    cvv: ""
  }
  amountToAdd: any;
  userData : any;
  beneficiaryList : any;
  userPhoneNumber: any;
  userTransferType: any;
  bankAccountTransferType: any;
  showProceed = false;
  hideRegister = true;
  payMethodUser: any;
  constructor(public router: Router, public alertController: AlertController,
    private authService: AuthService,
    private storageService: StorageService,
    private toastService: ToastService,
    private ionLoader: LoaderService) { 
      this.getUserDetails();
    }
  
  async getUserDetails() {
    const returnedData = await this.storageService.get(AuthConstants.AUTH)
    this.userData = returnedData?.info;
    this.userPhoneNumber = this.userData.phone;
    this.addMoneyData.phoneNumber = this.userData.phone;
    // this.getUserBeneficiary(this.userPhoneNumber);
    return this.userData;
  }

  // async getUserBeneficiary(phone) {
  //   console.log("loggedin phone:::", phone);
  //   this.authService.getUserBeneficiary(phone).subscribe((res: any) => {
  //       console.log("get beneficiary result :", res)
  //       this.hideLoader();
  //       if (res.success) {
  //         this.beneficiaryList = res.data;
  //       } else {
  //         console.log("beneficiary else :", res)
  //       }
  //     },
  //     (error: any) => {
  //       console.log("beneficiary error :", error)
  //       // this.hideLoader();
  //       // this.presentAlert(error?.error?.message);
  //       // this.toastService.presentToast(error?.error?.message);
  //     }
  //   );
  // }

  // onChangeBeneficiary(beneficiary) {
  //   this.addMoneyData.accountName = this.beneficiaryUser.accountName;
  //   this.addMoneyData.accountNumber = this.beneficiaryUser.accountNumber;
  //   this.addMoneyData.beneficiary = this.beneficiaryUser._id;
  // }

  defaultAmount(staticAmount) {
    this.addMoneyData.amount = this.amountToAdd = staticAmount;
  }

  
  validateMoneyInputs() {
    let amount = String(this.addMoneyData.amount);
    let phoneNumber = this.addMoneyData.phoneNumber;
    let pinCode = String(this.addMoneyData.pinCode);
    const retStatus = (amount.length > 0 &&phoneNumber.length > 0 && pinCode.length > 0);
    console.log("money inputs:::", retStatus)
    return retStatus;
  }

  registerData() {
    console.log(this.addMoneyData);
    this.showProceed = true;
    this.hideRegister = false;
  }

  confirmData() {
    console.log("data:::", this.addMoneyData);
    // console.log("validateBeneficiaryInputs:::", this.validateBeneficiaryInputs());
    if(this.validateMoneyInputs()) {
      this.showLoader();
      this.addMoneyData.amount = String(this.addMoneyData.amount);
      this.authService.postApiUrl("/wallet", this.addMoneyData).subscribe((res: any) => {
          console.log("add money result :", res)
          this.hideLoader();
          if (res.success) {
            this.storageService.store(AuthConstants.WALLETBALANCE, res.data?.info?.amount);
            // this.router.navigate(['/tabs']);
            this.presentAlert(res.message);
            this.toastService.presentToast('Money added successfully.');
            setTimeout(() => {
              this.showProceed = false;
              this.hideRegister = true;
              this.router.navigate(['/tabs']);
            }, 2000);
          } else {
            this.showProceed = false;
            this.hideRegister = true;
            this.presentAlert(res.message);
            this.toastService.presentToast(res.message);
          }
        },
        (error: any) => {
          // console.log("login error :", error)
              this.showProceed = false;
              this.hideRegister = true;
              this.hideLoader();
              this.presentAlert(error?.error?.message);
              this.toastService.presentToast(error?.error?.message);
        }
      );
    } else {
      this.toastService.presentToast('Please fill corresponding fields');
    }
  }

  onChangePayMethod(pmethod) {
    console.log(pmethod.detail.value)
    console.log(this.payMethodUser)
    this.addMoneyData.payMethod = this.payMethodUser;
    this.addMoneyData.payType = this.payMethodUser.payType;
  }

  async presentAlert(msg) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Add Money',
      message: msg,
      buttons: ['OK']
    });
    await alert.present();
    await alert.onDidDismiss();
  }

  showLoader() {
    this.ionLoader.showLoader();
    setTimeout(() => {
      this.hideLoader();
    }, 3000);
  }

  hideLoader() {
    this.ionLoader.hideLoader();
  }


}
