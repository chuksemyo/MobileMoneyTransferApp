import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newbankaccount',
  templateUrl: './newbankaccount.page.html',
  styleUrls: ['./newbankaccount.page.scss'],
})
export class NewbankaccountPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
