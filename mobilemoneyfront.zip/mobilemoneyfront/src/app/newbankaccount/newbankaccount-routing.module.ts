import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NewbankaccountPage } from './newbankaccount.page';

const routes: Routes = [
  {
    path: '',
    component: NewbankaccountPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NewbankaccountPageRoutingModule {}
