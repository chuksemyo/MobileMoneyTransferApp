import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewbankaccountPageRoutingModule } from './newbankaccount-routing.module';

import { NewbankaccountPage } from './newbankaccount.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewbankaccountPageRoutingModule
  ],
  declarations: [NewbankaccountPage]
})
export class NewbankaccountPageModule {}
