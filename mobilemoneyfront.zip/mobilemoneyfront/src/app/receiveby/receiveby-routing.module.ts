import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReceivebyPage } from './receiveby.page';

const routes: Routes = [
  {
    path: '',
    component: ReceivebyPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReceivebyPageRoutingModule {}
