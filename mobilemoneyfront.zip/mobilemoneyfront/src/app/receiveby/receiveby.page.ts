import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthConstants } from './../config/auth-constants';
import { AuthService } from './../services/auth.service';
import { StorageService } from './../services/storage.service';
import { ToastService } from './../services/toast.service';

@Component({
  selector: 'app-receiveby',
  templateUrl: './receiveby.page.html',
  styleUrls: ['./receiveby.page.scss'],
})
export class ReceivebyPage {
  userData : any
  loggedInUser: {}
  constructor(private authService: AuthService,
    private toastService: ToastService,
    private storageService: StorageService,
    private router: Router) {
      this.getUserDetails();
    }

    async getUserDetails() {
      const returnedData = await this.storageService.get(AuthConstants.AUTH)
      this.userData = returnedData?.info;
      console.log("loggedin details:::", this.userData);
      return this.userData;
    }

}
