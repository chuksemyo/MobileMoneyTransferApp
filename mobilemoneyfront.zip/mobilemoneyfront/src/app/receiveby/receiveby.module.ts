import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReceivebyPageRoutingModule } from './receiveby-routing.module';

import { ReceivebyPage } from './receiveby.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReceivebyPageRoutingModule
  ],
  declarations: [ReceivebyPage]
})
export class ReceivebyPageModule {}
