import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TranxhistoryPage } from './tranxhistory.page';

const routes: Routes = [
  {
    path: '',
    component: TranxhistoryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TranxhistoryPageRoutingModule {}
