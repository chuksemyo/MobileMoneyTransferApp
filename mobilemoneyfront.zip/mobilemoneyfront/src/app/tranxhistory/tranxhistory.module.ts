import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TranxhistoryPageRoutingModule } from './tranxhistory-routing.module';

import { TranxhistoryPage } from './tranxhistory.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TranxhistoryPageRoutingModule
  ],
  declarations: [TranxhistoryPage]
})
export class TranxhistoryPageModule {}
