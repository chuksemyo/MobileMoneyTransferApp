import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tranxhistory',
  templateUrl: './tranxhistory.page.html',
  styleUrls: ['./tranxhistory.page.scss'],
})
export class TranxhistoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
