import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfermoney',
  templateUrl: './transfermoney.page.html',
  styleUrls: ['./transfermoney.page.scss'],
})
export class TransfermoneyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
