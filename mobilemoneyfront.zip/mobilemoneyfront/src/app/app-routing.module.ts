import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'tabs',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
  },
  { path: '', loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule) },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'forgotpin',
    loadChildren: () => import('./forgotpin/forgotpin.module').then( m => m.ForgotpinPageModule)
  },
  {
    path: 'verification',
    loadChildren: () => import('./verification/verification.module').then( m => m.VerificationPageModule)
  },
  {
    path: 'setpin',
    loadChildren: () => import('./setpin/setpin.module').then( m => m.SetpinPageModule)
  },
  {
    path: 'addprofilepicture',
    loadChildren: () => import('./addprofilepicture/addprofilepicture.module').then( m => m.AddprofilepicturePageModule)
  },  {
    path: 'notification',
    loadChildren: () => import('./notification/notification.module').then( m => m.NotificationPageModule)
  },
  {
    path: 'updatepin',
    loadChildren: () => import('./updatepin/updatepin.module').then( m => m.UpdatepinPageModule)
  },
  {
    path: 'receiveby',
    loadChildren: () => import('./receiveby/receiveby.module').then( m => m.ReceivebyPageModule)
  },
  {
    path: 'paymethod',
    loadChildren: () => import('./paymethod/paymethod.module').then( m => m.PaymethodPageModule)
  },
  {
    path: 'tranxhistory',
    loadChildren: () => import('./tranxhistory/tranxhistory.module').then( m => m.TranxhistoryPageModule)
  },
  {
    path: 'paymethodadd',
    loadChildren: () => import('./paymethodadd/paymethodadd.module').then( m => m.PaymethodaddPageModule)
  },
  {
    path: 'transfermoney',
    loadChildren: () => import('./transfermoney/transfermoney.module').then( m => m.TransfermoneyPageModule)
  },
  {
    path: 'sendmoney',
    loadChildren: () => import('./sendmoney/sendmoney.module').then( m => m.SendmoneyPageModule)
  },
  {
    path: 'newbeneficiary',
    loadChildren: () => import('./newbeneficiary/newbeneficiary.module').then( m => m.NewbeneficiaryPageModule)
  },
  {
    path: 'cards',
    loadChildren: () => import('./cards/cards.module').then( m => m.CardsPageModule)
  },
  {
    path: 'cardsadd',
    loadChildren: () => import('./cardsadd/cardsadd.module').then( m => m.CardsaddPageModule)
  },
  {
    path: 'addmoney',
    loadChildren: () => import('./addmoney/addmoney.module').then( m => m.AddmoneyPageModule)
  },
  {
    path: 'newbankaccount',
    loadChildren: () => import('./newbankaccount/newbankaccount.module').then( m => m.NewbankaccountPageModule)
  },
  {
    path: 'sharemoney',
    loadChildren: () => import('./sharemoney/sharemoney.module').then( m => m.SharemoneyPageModule)
  }




];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
