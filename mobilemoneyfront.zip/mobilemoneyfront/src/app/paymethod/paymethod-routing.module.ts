import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymethodPage } from './paymethod.page';

const routes: Routes = [
  {
    path: '',
    component: PaymethodPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymethodPageRoutingModule {}
