import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-paymethod',
  templateUrl: './paymethod.page.html',
  styleUrls: ['./paymethod.page.scss'],
})
export class PaymethodPage implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }

  addNew() {
    this.router.navigate(['/paymethodadd']);
  }

}
