import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PaymethodPageRoutingModule } from './paymethod-routing.module';

import { PaymethodPage } from './paymethod.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PaymethodPageRoutingModule
  ],
  declarations: [PaymethodPage]
})
export class PaymethodPageModule {}
