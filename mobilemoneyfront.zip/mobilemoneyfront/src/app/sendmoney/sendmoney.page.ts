import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sendmoney',
  templateUrl: './sendmoney.page.html',
  styleUrls: ['./sendmoney.page.scss'],
})
export class SendmoneyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
