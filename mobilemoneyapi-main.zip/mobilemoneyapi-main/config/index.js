module.exports = {
    seedData: true,
    // dbConnection: "mongodb://127.0.0.1:27017/mobilemoney",
    dbConnection: "mongodb+srv://kanmit:Notice2022@cluster0.d0487.mongodb.net/mobilemoney",
    numberOfUsers: 15,

    mailUser: "ttconfirmed@gmail.com",
    mailPassword: "",

    currency: "NGN",
    country: "Nigeria",
}